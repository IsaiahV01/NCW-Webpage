<?php

$hn = "localhost";
$un = "isaiah";
$pw = "O1FAxzy29Iufg";
$db = "ncw_database";



$index = "Location: index.html";
?>